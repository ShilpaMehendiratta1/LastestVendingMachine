using NUnit.Framework;
using VendingMachine.Models;
using VendingMachine.Services;
using System.Linq;

namespace VendingMachine.Tests
{
    public class VendingMachineTests
    {
        private Services.VendingMachine machine;

        [SetUp]
        public void Setup()
        {
            machine = new Services.VendingMachine();
        }

        [TestCase(CoinType.Nickel, 0.05)]
        [TestCase(CoinType.Dime, 0.10)]
        [TestCase(CoinType.Quarter, 0.25)]
        public void Insert_Valid_Coins_Should_Update_Display(CoinType coin, decimal expectedAmount)
        {
            machine.InsertCoin(coin);
            Assert.AreEqual($"${expectedAmount:0.00}", machine.DisplayMessage);
        }

        [TestCase(CoinType.Penny)]
        public void Insert_Invalid_Coin_Should_Go_To_CoinReturn(CoinType coin)
        {
            machine.InsertCoin(coin);

            Assert.AreEqual(1, machine.CoinReturn.Count);
            Assert.IsTrue(machine.CoinReturn.Contains(coin));
            Assert.AreEqual("INSERT COIN", machine.DisplayMessage);
        }

        [TestCase(ProductType.Candy, 0.65, "PRICE $0.65")]
        [TestCase(ProductType.Chips, 0.50, "PRICE $0.50")]
        [TestCase(ProductType.Cola, 1.00, "PRICE $1.00")]
        public void Select_Product_Without_Enough_Money_Should_Show_Price(ProductType product, decimal price, string expectedMessage)
        {
            machine.InsertCoin(CoinType.Dime);

            var result = machine.SelectProduct(product);
            Assert.AreEqual(expectedMessage, result);
        }

        [TestCase(ProductType.Candy, 0.65)]
        [TestCase(ProductType.Chips, 0.50)]
        [TestCase(ProductType.Cola, 1.00)]
        public void Select_Product_With_Enough_Money_Should_Dispense(ProductType product, decimal price)
        {
            // Insert enough coins to cover the product price
            while (price >= 0.25m)
            {
                machine.InsertCoin(CoinType.Quarter);
                price -= 0.25m;
            }
            while (price >= 0.10m)
            {
                machine.InsertCoin(CoinType.Dime);
                price -= 0.10m;
            }
            while (price >= 0.05m)
            {
                machine.InsertCoin(CoinType.Nickel);
                price -= 0.05m;
            }

            var result = machine.SelectProduct(product);

            Assert.AreEqual("THANK YOU", result);
            Assert.AreEqual("INSERT COIN", machine.DisplayMessage);
        }
    }
}
